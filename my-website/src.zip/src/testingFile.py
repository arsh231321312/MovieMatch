with open('yourfile.txt', 'a') as file:
    # Write a line to the file
    file.write('This line will be appended to the file.\n')