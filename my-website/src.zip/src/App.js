
import { SignUpForm, SignInForm, FrontPage, ResetPasswordForm,MainPage} from './AFunctions';
import CryptoJS from 'crypto-js';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';

function App() { 
     
    return ( 
      

      
        <div >
          
          <Router>
            <Routes>
              <Route path="/" element={<FrontPage />} />
              <Route path="/Register" element={<SignUpForm />} />
              <Route path="/Login" element={<SignInForm />} />
              <Route path="/resetPassword" element={<ResetPasswordForm />} />
              <Route path="/mainPage" element={<MainPage />} />
            </Routes>
          </Router>
         </div>
      
      
    ); 
} 
  
export default App; 
