import mysql.connector
# Establish the connection
connection = mysql.connector.connect(
    host="localhost",        # Your host, e.g., localhost or AWS RDS instance
    user="root",    # Your MySQL username
    password="Sandhu57628136$",# Your MySQL password
    database="newdata" # The database you want to connect to
)
# Check if connection was successful
if connection.is_connected():
    print("Connection successful!")
else:
    print("Connection failed.")
# Create a cursor object
cursor = connection.cursor()
# Execute a query
cursor.execute("INSERT INTO users (username_hash,password_hash,email_hash) VALUES ('test','test','test')")
# Fetch the data
data = cursor.fetchall()
print(data)
# Commit the transaction
connection.commit()
# Close the cursor
cursor.close()
# Close the connection when done
connection.close()
