import requests
from bs4 import BeautifulSoup
import time
from collections import deque

# Replace with the URL you want to scrape

        
url = 'https://www.themoviedb.org/tv/13916-death-note'

# Send a GET request to the URL
response = requests.get(url)
soup = BeautifulSoup(response.content, 'html.parser')
img=soup.find('div',class_='blurred')
img=img.find('img')
print(img.get('src'))
# <div class="blurred" style="background-image: url('https://media.themoviedb.org/t/p/w300_and_h450_multi_faces_filter(blur)/tCZFfYTIwrR7n94J6G14Y4hAFU6.jpg');">
#                 <img class="poster w-full" src="https://media.themoviedb.org/t/p/w300_and_h450_bestv2/tCZFfYTIwrR7n94J6G14Y4hAFU6.jpg" srcset="https://media.themoviedb.org/t/p/w300_and_h450_bestv2/tCZFfYTIwrR7n94J6G14Y4hAFU6.jpg 1x, https://media.themoviedb.org/t/p/w600_and_h900_bestv2/tCZFfYTIwrR7n94J6G14Y4hAFU6.jpg 2x" alt="Death Note">

#         </div>
    
    
    
    
    
    

