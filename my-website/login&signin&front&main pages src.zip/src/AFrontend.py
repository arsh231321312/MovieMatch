from flask import Flask, request, jsonify
from flask_cors import CORS
app=Flask(__name__)

users={}
emailsUsed={}
CORS(app)


@app.route("/3000", methods=["POST"])
def handling_data():
    data = request.get_json()  # Get JSON data from the request
    type= data.get('type')
    username = data.get('username')
    password = data.get('password')
    email = data.get('email')
    print(f"Type: {type}")
    print(f"Email: {email}")
    if (type== "signin"):
        if(email == True):
            if username not in emailsUsed:
                return jsonify({"status": "failure", "message": "Sign in failed, email does not exist"})
            else:
                if emailsUsed[username] != password:
                    return jsonify({"status": "failure", "message": "Sign in failed, password is incorrect"})
                else:
                    return jsonify({"status": "success", "message": "Sign in with email successful"})
        elif(email == False):
            if username not in users:
                return jsonify({"status": "failure", "message": "Sign in failed, username does not exist"})
            else:
                if users[username] != password:
                    return jsonify({"status": "failure", "message": "Sign in failed, password is incorrect"})
                else:
                    return jsonify({"status": "success", "message": "Sign in successful"})
        else:
            return jsonify({"status": "failure", "message": "Sign in failed, due to an error on our end please make a ticket or send an email to arsh.singh.sandhu1@gmail.com"})
    elif (type == "register"):
        if email in emailsUsed:
            return jsonify({"status": "failure", "message": "Sign up failed, email is already used"})
        if username in users:
            return jsonify({"status": "failure", "message": "Sign up failed, username is already used"})
        if email not in emailsUsed and username not in users:
            users[username]=password
            emailsUsed[email]=password
            with open('accounts.txt', 'a') as file:
                file.write(email+"\n"+username + "\n" + password + "\n")

            return jsonify({"status": "success", "message": "Account created!"})
    else:
        return jsonify({"status": "failure", "message": "Sign up failed, due to an error on our end please make a ticket or send an email to"})
 
def initial_data():
    print("Initial data")
    with open('accounts.txt', 'r') as file:
        while True:
            email = file.readline().strip()
            user = file.readline().strip()
            password = file.readline().strip()
            if (not email) or (not user) or (not password):
                print("End of file")
                break
            emailsUsed[email] = password
            users[user] = password
    print("Initial data end")


           
        
if __name__ == "__main__":
    print("started")
    initial_data()
    app.run(debug=True)
